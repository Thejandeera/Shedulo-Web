package com.example.shedulo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SheduloApplication {

	public static void main(String[] args) {
		SpringApplication.run(SheduloApplication.class, args);
	}

}
